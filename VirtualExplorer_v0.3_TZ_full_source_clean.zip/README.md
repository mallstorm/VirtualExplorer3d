# Virtual Explorer

Virtual Reality Explorer Engine на Godot 4 для Android-приложений с интерактивным исследованием виртуальных пространств.

Первая демонстрация: `Chernobyl Sarcophagus Experience`.

## Что реализовано

### Этап 1 - MVP 3D

- Godot 4 project.
- Запускаемая сцена `scenes/Main.tscn`.
- 3D игрок от первого лица.
- Камера высотой 1.75 м, FOV 78.
- Ходьба мышь/клавиатура + сенсорная подготовка.
- Комната реакторного блока со стенами, полом, потолком и коллизиями.
- Освещение: DirectionalLight + аварийный OmniLight.
- Интерактивный объект `reactor_panel`.

### Этап 2 - 360 и интерактив

- Панорамный viewer через внутреннюю сферу.
- Портал из 3D-комнаты в 360-точку.
- Точки интереса через raycast.
- Информационная панель HUD.
- Структура под 3D Audio и голосовые экскурсии.

### Этап 3 - расширение движка

- Импорт ZIP-проектов в `user://Explorer/Projects`.
- Формат внешнего `project.json`.
- VR Cardboard foundation.
- AI Depth foundation.
- Photogrammetry model scanner foundation.
- GitHub Actions workflow для Godot export.

## Запуск

Открыть папку проекта в Godot 4.x и запустить `scenes/Main.tscn`.

Для теста:

- WASD/стрелки - движение;
- мышь - обзор;
- E - взаимодействие с объектом;
- Esc - освободить мышь / выйти из 360-сцены;
- G - зарезервировано под gyro;
- V - зарезервировано под VR mode.

## Android

Цель первой версии:

- Android 9+;
- API 28+;
- 4 GB RAM;
- Adreno 610+;
- 30 FPS минимум.

Экспорт готовится через `export_presets.cfg` и GitHub Actions.

## Структура

```text
Core/
Player/
Renderer/
UI/
Projects/Chernobyl/
Assets/
.github/workflows/
```

## Важное

В репозитории нет тяжёлых реальных ассетов. Панорамы, звук и модели добавляются отдельно:

- `Projects/Chernobyl/panoramas/`
- `Projects/Chernobyl/audio/`
- `Assets/Models/`
- `Assets/Textures/`

Это сделано, чтобы держать APK меньше 100 MB.
